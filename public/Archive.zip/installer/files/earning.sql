INSERT INTO `earning` (`ID`, `user_id`, `amount`, `net_amount`, `balance`, `payout`) VALUES
(1, 1, 4742.300000, 6.930000, 6.930000, 0.000000);