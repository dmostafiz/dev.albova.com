INSERT INTO `menu` (`menu_id`, `menu_title`, `menu_position`, `created_at`) VALUES
(1, 'Main menu', 'primary', '1577381924'),
(2, 'Footer 1', NULL, '1578043825'),
(3, 'Footer 2', NULL, '1578043880');