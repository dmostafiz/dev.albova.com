INSERT INTO `coupon` (`coupon_id`, `coupon_code`, `coupon_description`, `start_time`, `end_time`, `coupon_price`, `price_type`, `service_type`, `author`, `created_at`, `status`) VALUES
(1, 'NEWYEAR2020', 'Happy new year 2020', '1577318400', '1578182400', 20.00000, 'percent', NULL, 1, 1579187837, 'on'),
(2, 'VALENTINE', 'Valentine\'s day', '1581465600', '1581984000', 50.00000, 'fixed', NULL, 1, 1579187891, 'off'),
(3, 'NEWCOUPON', 'Add new a coupon', '1579132800', '1579651200', 30.00000, 'percent', NULL, 1, 1579188140, 'on');