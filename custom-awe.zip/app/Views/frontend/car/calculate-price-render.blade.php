<div class="total-render d-flex align-items-center">
    <h5>{{ __('Total') }}</h5>
    <div class="price-wrapper ml-auto">
        <span class="price">{!! balanceTags(convert_price($total)) !!}</span>
    </div>
</div>
