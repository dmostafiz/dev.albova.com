<a class="btn btn-success waves-effect waves-light" href="{{ dashboard_url('add-new-car') }}">
    <i class="ti-plus mr-1"></i>
   {{__('Create New')}}
</a>
